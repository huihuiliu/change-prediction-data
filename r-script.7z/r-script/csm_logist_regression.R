
#######################################################################################
### recommended RStudio to run the following code
### NOTICE: sometimes you need to set working directory, e.g.:
### setwd("/home/yang/share/empire")
###
### setwd("C:/Desktop/lhh/dc")
### install.packages("packagename")  install.packages("devEMF")
### require()
### lsr.d = lsr::cohensD(x, y, method = "corrected") ## library(lsr, quietly=TRUE)
### print(paste("lsr.d = ", lsr.d, sep=""), quote=F)
### 
### effsize.d = effsize::cohen.d(x, y) ## library(effsize, quietly=TRUE)
### print(paste("effsize.d = ", effsize.d$estimate, sep="") , quote=F)
###
### modified by lhh in 2018-2-25
#######################################################################################

# library(car)
# library(perturb)
# library(plyr, quietly=TRUE)
# library(usdm, quietly=TRUE)
library(effsize, quietly=TRUE)
library(lsr, quietly = TRUE) #  cohensD() for wilcox test
library(devEMF, quietly = TRUE) # to plot high-quality vector-graph

rm(list = ls()) ## run rm before starting to find potential bugs, e.g., unvalid variables

plot.single.effort.ranking <- function(projectNames, ynames, modelComparisonNames, cutoffs, inputPath, outputPath)
{
  cutoffs <- paste("CE.E.", cutoffs, sep="")  ## "CE.E.0.1" "CE.E.0.2" "CE.E.1"
  for (projectName in projectNames) {
    for(i in seq(1:length(ynames))) {
      yname <- ynames[i]
      for (modelComparisonName in modelComparisonNames) {
        targetModelName <- NULL  ## our model
        boxLabelName <- NULL  ## our model label
        if(modelComparisonName == "B-VS-S") {targetModelName <- "S"; boxLabelName <- "S"}
        if(modelComparisonName == "B-VS-BS") {targetModelName <- "B+S"; boxLabelName <- "B+S"}
        
        for(cutoff in cutoffs) {
          ## inputPath = "C:/Desktop/apsec/result"
          readPath <- paste(inputPath, "/data/data_", projectName, "_", yname, "_", modelComparisonName, sep="")
          eachModelResult <- dget(file=readPath)
          
          ##print(readPath)
          
          basicResult <- eachModelResult[["B"]][["matrix.CEs"]]
          targetResult <- eachModelResult[[targetModelName]][["matrix.CEs"]]
          
          X <- basicResult[, cutoff]
          Y <- targetResult[, cutoff]
          data.all <- cbind(X, Y)
          
          scols <- rep("black", 2)
          #PV <- wilcox.test(X, Y, paired=TRUE)$"p.value"
          #CD <- effsize::cliff.delta(X, Y)$"estimate"
          #if ((PV <= 0.05) && (CD >=  0.147)) { scols[2] <- "red"  }
          #if ((PV <= 0.05) && (CD <= -0.147)) { scols[2] <- "blue" }
          
          ## fout <- "C:/Desktop/apsec/result"
          fout <- paste(outputPath, "/plot/", projectName, "/", yname, "_", cutoff, "_", modelComparisonName, "_", projectName, ".emf", sep="")

          ## check whether exists such file or directory
          parent.directory <- dirname(fout)
          while (file.exists(parent.directory) == FALSE){
            dir.create(parent.directory, recursive = TRUE)
            parent.directory <- dirname(parent.directory)
          }
          file.create(fout) 
          
          emf(file = fout, width=0.6, height=0.8, bg = "transparent", fg = "black", pointsize = 12, family = "Helvetica")
          
          par(mar=c(0, 0, 0, 0), oma=c(0.8, 1.0, 0.6, 0.1), cex=0.6)
          boxplot(data.all, xlab="", ylab="", xaxt="n", boxwex=0.4, frame=FALSE, outline=FALSE, border=scols, axes=FALSE)
          box(bty="o", mgp=c(1, 1, 0))
          axis(2, mgp=c(0.05, 0.12, 0), tck=-0.02, cex.axis=1)
          text(x=c(1, 2), y=par("usr")[3], labels=c("B", boxLabelName), cex=0.8, adj=c(0.5, 1.5), xpd=NA)
          
          dev.off()
        }
      }
    }
  }
}

plot.single.effort.classification <- function(projectNames, ynames, modelComparisonNames, cutoffs, inputPath, outputPath)
{
  cutoffs <- c("BPP", "BCE", "AVG")  ## c("BPP", "BCE", "MFM", "AVG")
  for (projectName in projectNames) {
    for(i in seq(1:length(ynames))) {
      yname <- ynames[i]
      for (modelComparisonName in modelComparisonNames) {
        targetModelName <- NULL  ## our model
        boxLabelName <- NULL  ## our model label
        if(modelComparisonName == "B-VS-S") {targetModelName <- "S"; boxLabelName <- "S"}
        if(modelComparisonName == "B-VS-BS") {targetModelName <- "B+S"; boxLabelName <- "B+S"}
        
        for(cutoff in cutoffs) {
          ## inputPath = "C:/Desktop/apsec/result
          readPath <- paste(inputPath, "/data/data_", projectName, "_", yname, "_", modelComparisonName, sep="")
          eachModelResult <- dget(file=readPath)
          
          ##print(readPath)
          
          basicResult <- eachModelResult[["B"]][["matrix.ERs"]]
          targetResult <- eachModelResult[[targetModelName]][["matrix.ERs"]]
          
          X <- basicResult[, cutoff]
          Y <- targetResult[, cutoff]
          data.all <- cbind(X, Y)
          
          scols <- rep("black", 2)
          PV <- wilcox.test(X, Y, paired=TRUE)$"p.value"
          CD <- effsize::cliff.delta(X, Y)$"estimate"
          #if ((PV <= 0.05) && (CD >=  0.147)) { scols[2] <- "red"  }
          #if ((PV <= 0.05) && (CD <= -0.147)) { scols[2] <- "blue" }
          
          fout <- paste(outputPath, "/plot/", projectName, "/", yname, "_", cutoff, "_", modelComparisonName, "_", projectName, ".emf", sep="")
         
          ## check whether exists such file or directory
          parent.directory <- dirname(fout)
          while (file.exists(parent.directory) == FALSE){
            dir.create(parent.directory, recursive = TRUE)
            parent.directory <- dirname(parent.directory)
          }
          file.create(fout) 
          
          emf(file = fout, width=0.6, height=0.8, bg = "transparent", fg = "black", pointsize = 12, family = "Helvetica")
          
          par(mar=c(0, 0, 0, 0), oma=c(0.8, 1.0, 0.6, 0.1), cex=0.6)
          boxplot(data.all, xlab="", ylab="", xaxt="n", boxwex=0.4, frame=FALSE, outline=FALSE, border=scols, axes=FALSE)
          box(bty="o", mgp=c(1, 1, 0))
          axis(2, mgp=c(0.05, 0.12, 0), tck=-0.02, cex.axis=1)
          text(x=c(1, 2), y=par("usr")[3], labels=c("B", boxLabelName), cex=0.8, adj=c(0.5, 1.5), xpd=NA)
          
          dev.off()
        }
      }
    }
  }
}

## filenames is the paths of projects results
table.effort.ranking <- function(projectNames, ynames, modelComparisonNames, cutoffs, inputPath, outputPath)
{
  cutoffs <- paste("CE.E.", cutoffs, sep="")  ## "CE.E.0.1" "CE.E.0.2" "CE.E.1"
  for (projectName in projectNames) {
    for(i in seq(1:length(ynames))) {
      yname <- ynames[i]
      for (mdlComparisonName in modelComparisonNames) {
        targetModelName <- NULL  ## our model
        if(mdlComparisonName == "B-VS-S") {targetModelName <- "S";}
        if(mdlComparisonName == "B-VS-BS") {targetModelName <- "B+S";}
        
        ## process one prediction model for a given project
        oneModelResult <- NULL
        for(cutoff in cutoffs) {
          ## inputPath = "C:/Desktop/apsec/result
          readPath <- paste(inputPath, "/data_", projectName, "_", yname, "_", mdlComparisonName, sep="")
          eachModelResult <- dget(file=readPath)
          
          basicResult <- eachModelResult[["B"]][["matrix.CEs"]]
          targetResult <- eachModelResult[[targetModelName]][["matrix.CEs"]]
          
          X <- basicResult[, cutoff]
          Y <- targetResult[, cutoff]
          
          X[X == 0] <- 0.0001  ##  if basic < 0, it indicates that it is worse than the random model, 
          Y[Y == 0] <- 0.0001
          
          ## calculate win/tie/loss
          diff <- Y - X
          win <- length(which(diff > 0))
          tie <- length(which(diff == 0))
          loss <- length(which(diff < 0))
          WinTieLoss <- paste(win,"-", tie, "-", loss, sep="")
          
          PV <- wilcox.test(X, Y, paired=TRUE)$"p.value"
          ## CD <- effsize::cliff.delta(X, Y)$"estimate"
          
          ## method = "corrected"
          ## is the unbiased estimator of d which multiplies the "pooled" version by (n-3)/(n-2.25) 
          CD = lsr::cohensD(X, Y, method="corrected") 
          
          dataOneCutoff <-data.frame(median(X), median(Y), PV, CD) ## X Y PV CD
          
          ## PV: wilcox.p.value, CliffD: cliff.delta
          if(mdlComparisonName == "B-VS-S") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          if(mdlComparisonName == "B-VS-BS") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          rownames(dataOneCutoff) <- paste(projectName, ".", yname, ".", mdlComparisonName, ".", cutoff, sep="")
          dataOneCutoff$improve <- (dataOneCutoff[, targetModelName] - dataOneCutoff[, "B"])/dataOneCutoff[, "B"]
          #dataOneCutoff <- round(dataOneCutoff, 3)
          dataOneCutoff <- cbind(dataOneCutoff, WinTieLoss)
          dataOneCutoff <- dataOneCutoff[, c("B", targetModelName, "improve", "CliffDelta", "PV", "WinTieLoss")]  ## choose some columns as new dataframe
          
          oneModelResult <- rbind(oneModelResult, dataOneCutoff)
        }
        print(oneModelResult)
        
        ##fout = "C:/Desktop/apsec/result
        fout <- paste(outputPath, "/evaluation/CE/", projectName, "/CE_", projectName, "_", yname, "_", mdlComparisonName, ".csv", sep="")  ## "B-VS-B" or "B-VS-BS"
        
        parent.directory <- dirname(fout)
        while (file.exists(parent.directory) == FALSE){
          dir.create(parent.directory, recursive = TRUE)
          parent.directory <- dirname(parent.directory)
        }
        file.create(fout) 
        
        write.csv(oneModelResult, fout)
      }
    }
  }
}

## filenames is the paths of projects results
table.effort.ranking2 <- function(projectNames, ynames, modelComparisonNames, cutoffs, inputPath, outputPath)
{
  cutoffs <- paste("CE.E.", cutoffs, sep="")  ## "CE.E.0.1" "CE.E.0.2" "CE.E.1"
  for (mdlComparisonName in modelComparisonNames) {
    targetModelName <- NULL  ## our model
    if(mdlComparisonName == "B-VS-S") {targetModelName <- "S";}
    if(mdlComparisonName == "B-VS-BS") {targetModelName <- "B+S";}
    
    oneModelResult <- NULL
    for (projectName in projectNames) {
      for(i in seq(1:length(ynames))) {
        yname <- ynames[i]
        ## process one prediction model for a given project
        
        for(cutoff in cutoffs) {
          ## inputPath = "C:/Desktop/apsec/result"
          readPath <- paste(inputPath, "/data/data_", projectName, "_", yname, "_", mdlComparisonName, sep="")
          eachModelResult <- dget(file=readPath)
          
          basicResult <- eachModelResult[["B"]][["matrix.CEs"]]
          targetResult <- eachModelResult[[targetModelName]][["matrix.CEs"]]
          
          X <- basicResult[, cutoff]
          Y <- targetResult[, cutoff]
          
          X[X == 0] <- 0.0001  ##  if basic < 0, it indicates that it is worse than the random model, 
          Y[Y == 0] <- 0.0001
          
          ## calculate win/tie/loss
          diff <- Y - X
          win <- length(which(diff > 0))
          tie <- length(which(diff == 0))
          loss <- length(which(diff < 0))
          WinTieLoss <- paste(win,"-", tie, "-", loss, sep="")
          
          PV <- wilcox.test(X, Y, paired=TRUE)$"p.value"
          ## CD <- effsize::cliff.delta(X, Y)$"estimate"
          
          ## method = "corrected"
          ## is the unbiased estimator of d which multiplies the "pooled" version by (n-3)/(n-2.25) 
          CD = lsr::cohensD(X, Y, method="corrected") 
          
          dataOneCutoff <-data.frame(median(X), median(Y), PV, CD) ## X Y PV CD
          
          ## PV: wilcox.p.value, CliffD: cliff.delta
          if(mdlComparisonName == "B-VS-S") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          if(mdlComparisonName == "B-VS-BS") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          rownames(dataOneCutoff) <- paste(projectName, ".", yname, ".", mdlComparisonName, ".", cutoff, sep="")
          dataOneCutoff$improve <- (dataOneCutoff[, targetModelName] - dataOneCutoff[, "B"])/dataOneCutoff[, "B"]
          #dataOneCutoff <- round(dataOneCutoff, 3)
          dataOneCutoff <- cbind(dataOneCutoff, WinTieLoss)
          dataOneCutoff <- dataOneCutoff[, c("B", targetModelName, "improve", "CliffDelta", "PV", "WinTieLoss")]  ## choose some columns as new dataframe
          
          oneModelResult <- rbind(oneModelResult, dataOneCutoff)
        }
        
        #print(oneModelResult)
      }
    } ## project
  
    ## fout = "C:/Desktop/apsec/result"
    fout <- paste(outputPath, "/evaluation/CE-", mdlComparisonName, ".csv", sep="")  ## "B-VS-B" or "B-VS-BS"
    
    parent.directory <- dirname(fout)
    while (file.exists(parent.directory) == FALSE){
      dir.create(parent.directory, recursive = TRUE)
      parent.directory <- dirname(parent.directory)
    }
    file.create(fout) 
    
    write.csv(oneModelResult, fout)  
  }
}

table.effort.classification <- function(projectNames, ynames, modelComparisonNames, cutoffs, inputPath, outputPath)
{
  cutoffs <- c("BPP", "BCE", "AVG")  ## c("BPP", "BCE", "MFM", "AVG")
  for (projectName in projectNames) {
    for(i in seq(1:length(ynames))) {
      yname <- ynames[i]
      for (modelComparisonName in modelComparisonNames) {
        targetModelName <- NULL  ## our model
        if(modelComparisonName == "B-VS-S") {targetModelName <- "S"}
        if(modelComparisonName == "B-VS-BS") {targetModelName <- "B+S"}
        
        ## process one prediction model for a given project
        oneModelResult <- NULL
        for(cutoff in cutoffs) {
          ## inputPath = "C:/Desktop/apsec/result"
          readPath <- paste(inputPath, "/data/data_", projectName, "_", yname, "_", modelComparisonName, sep="")
          eachModelResult <- dget(file=readPath)
          
          basicResult <- eachModelResult[["B"]][["matrix.ERs"]]
          targetResult <- eachModelResult[[targetModelName]][["matrix.ERs"]]
          
          X <- basicResult[, cutoff]
          Y <- targetResult[, cutoff]
          
          X[X == 0] <- 0.0001  ##  if basic < 0, it indicates that it is worse than the random model, 
          Y[Y == 0] <- 0.0001
          
          ## calculate win/tie/loss
          diff <- Y - X
          win <- length(which(diff > 0))
          tie <- length(which(diff == 0))
          loss <- length(which(diff < 0))
          WinTieLoss <- paste(win,"-", tie, "-", loss, sep="")
          
          PV <- wilcox.test(X, Y, paired=TRUE)$"p.value"
          ## CD <- effsize::cliff.delta(X, Y)$"estimate"
          
          ## method = "corrected"
          ## is the unbiased estimator of d which multiplies the "pooled" version by (n-3)/(n-2.25) 
          CD = lsr::cohensD(X, Y, method="corrected") 
          
          dataOneCutoff <-data.frame(median(X), median(Y), PV, CD) ## X Y PV CD
          
          ## PV: wilcox.p.value, CliffD: cliff.delta
          if(modelComparisonName == "B-VS-S") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          if(modelComparisonName == "B-VS-BS") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          rownames(dataOneCutoff) <- paste(projectName, ".", yname, ".", modelComparisonName, ".", cutoff, sep="")
          dataOneCutoff$improve <- (dataOneCutoff[, targetModelName] - dataOneCutoff[, "B"])/dataOneCutoff[, "B"]
          #dataOneCutoff <- round(dataOneCutoff, 3)
          dataOneCutoff <- cbind(dataOneCutoff, WinTieLoss)
          
          ## choose some columns as new dataframe
          dataOneCutoff <- dataOneCutoff[, c("B", targetModelName, "improve", "CliffDelta", "PV", "WinTieLoss")]  
          
          oneModelResult <- rbind(oneModelResult, dataOneCutoff)
        }
        print(oneModelResult)
        
        ##fout = "C:/Desktop/apsec/result"
        fout <- paste(outputPath, "/evaluation/ER/", projectName, "/ER_", projectName, "_", yname, "_", modelComparisonName, ".csv", sep="")
        parent.directory <- dirname(fout)
        while (file.exists(parent.directory) == FALSE){
          dir.create(parent.directory, recursive = TRUE)
          parent.directory <- dirname(parent.directory)
        }
        file.create(fout) 
        
        write.csv(oneModelResult, fout)
      }
    }
  }
}

table.effort.classification2 <- function(projectNames, ynames, modelComparisonNames, cutoffs, inputPath, outputPath)
{
  cutoffs <- c("BPP", "BCE", "AVG")  ## c("BPP", "BCE", "MFM", "AVG")
  for (modelComparisonName in modelComparisonNames) {
    targetModelName <- NULL  ## our model
    if(modelComparisonName == "B-VS-S") {targetModelName <- "S"}
    if(modelComparisonName == "B-VS-BS") {targetModelName <- "B+S"}
    
    ## process one prediction model for a given project
    oneModelResult <- NULL
    for (projectName in projectNames) {
      for(i in seq(1:length(ynames))) {
        yname <- ynames[i]
        
        for(cutoff in cutoffs) {
          ## inputPath = "C:/Desktop/apsec/result"
          readPath <- paste(inputPath, "/data/data_", projectName, "_", yname, "_", modelComparisonName, sep="")
          eachModelResult <- dget(file=readPath)
          
          basicResult <- eachModelResult[["B"]][["matrix.ERs"]]
          targetResult <- eachModelResult[[targetModelName]][["matrix.ERs"]]
          
          X <- basicResult[, cutoff]
          Y <- targetResult[, cutoff]
          
          X[X == 0] <- 0.0001  ##  if basic < 0, it indicates that it is worse than the random model, 
          Y[Y == 0] <- 0.0001
          
          ## calculate win/tie/loss
          diff <- Y - X
          win <- length(which(diff > 0))
          tie <- length(which(diff == 0))
          loss <- length(which(diff < 0))
          WinTieLoss <- paste(win,"-", tie, "-", loss, sep="")
          
          PV <- wilcox.test(X, Y, paired=TRUE)$"p.value"
          ## CD <- effsize::cliff.delta(X, Y)$"estimate"
          
          ## method = "corrected"
          ## is the unbiased estimator of d which multiplies the "pooled" version by (n-3)/(n-2.25) 
          CD = lsr::cohensD(X, Y, method="corrected") 
          
          dataOneCutoff <-data.frame(median(X), median(Y), PV, CD) ## X Y PV CD
          
          ## PV: wilcox.p.value, CliffD: cliff.delta
          if(modelComparisonName == "B-VS-S") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          if(modelComparisonName == "B-VS-BS") {colnames(dataOneCutoff) <- c("B", targetModelName, "PV", "CliffDelta")}
          rownames(dataOneCutoff) <- paste(projectName, ".", yname, ".", modelComparisonName, ".", cutoff, sep="")
          dataOneCutoff$improve <- (dataOneCutoff[, targetModelName] - dataOneCutoff[, "B"])/dataOneCutoff[, "B"]
          #dataOneCutoff <- round(dataOneCutoff, 3)
          dataOneCutoff <- cbind(dataOneCutoff, WinTieLoss)
          
          ## choose some columns as new dataframe
          dataOneCutoff <- dataOneCutoff[, c("B", targetModelName, "improve", "CliffDelta", "PV", "WinTieLoss")]  
          
          oneModelResult <- rbind(oneModelResult, dataOneCutoff)
        }
        ##print(oneModelResult)
      }
    }
    
    ##fout = "C:/Desktop/apsec/result"
    fout <- paste(outputPath, "/evaluation/ER-", modelComparisonName, ".csv", sep="")
    parent.directory <- dirname(fout)
    while (file.exists(parent.directory) == FALSE){
      dir.create(parent.directory, recursive = TRUE)
      parent.directory <- dirname(parent.directory)
    }
    file.create(fout) 
    
    write.csv(oneModelResult, fout)
  }
}

extractEachStructualChangeType <- function(releasePath){
  mydata <- read.csv(releasePath, header = TRUE, sep = ",", stringsAsFactors = FALSE)
  
  scc.dt <- NULL ## fine-grained structual code change (SCC)
  for(i in 1:nrow(mydata)){
    eachRow <- mydata[i, "structuralChangeVector"]
    split <- as.numeric(strsplit(as.character(eachRow), " ")[[1]])
    scc.dt <- rbind(scc.dt, split)
  }
  
  rownames(scc.dt) <- rownames(mydata)
  colnames(scc.dt) <- c("adding_attribute_modifiability", "adding_class_derivability", "adding_method_overridability",
    "additional_class", "additional_functionality", "additional_object_state", "alternative_part_delete",
    "alternative_part_insert", "attribute_renaming", "attribute_type_change", "class_renaming", "comment_delete",
    "comment_insert", "comment_move", "comment_update", "condition_expression_change",
    "decreasing_accessibility_change", "doc_delete", "doc_insert", "doc_update",
    "increasing_accessibility_change", "method_renaming", "parameter_delete", "parameter_insert",
    "parameter_ordering_change", "parameter_renaming", "parameter_type_change", "parent_class_change",
    "parent_class_delete", "parent_class_insert", "parent_interface_change", "parent_interface_delete",
    "parent_interface_insert", "removed_class", "removed_functionality", "removed_object_state",
    "removing_attribute_modifiability", "removing_class_derivability", "removing_method_overridability",
    "return_type_change", "return_type_delete", "return_type_insert", "statement_delete", "statement_insert",
    "statement_ordering_change", "statement_parent_change", "statement_update", "unclassified_change")
  
  scc.dt <- as.data.frame(scc.dt)
  
  ## divide the fine-grained change types into three categories: api, state, func, stmt 
  newdata <- within(scc.dt, {
    api = parent_class_change + parent_class_delete + parent_class_insert + parent_interface_change + parent_interface_delete + 
      parent_interface_insert + removing_class_derivability + removing_method_overridability + decreasing_accessibility_change + parameter_delete + 
      parameter_insert + parameter_ordering_change + parameter_type_change + class_renaming + increasing_accessibility_change + method_renaming + 
      parameter_renaming + adding_class_derivability + adding_method_overridability + return_type_change + return_type_delete + return_type_insert;
    state = attribute_type_change + removed_object_state + removing_attribute_modifiability + attribute_renaming + adding_attribute_modifiability + 
      additional_object_state ;
    func = removed_class + additional_class + removed_functionality + additional_functionality  ;
    stmt = statement_insert + statement_ordering_change + statement_update + statement_delete + statement_parent_change + condition_expression_change + 
      alternative_part_delete + alternative_part_insert;
    
    apiNUM = api;
    stateNUM = state;
    funcNUM = func;
    stmtNUM = stmt }
  )
  
  newframe <- subset(newdata, select = c(api, state, func, stmt, apiNUM, stateNUM, funcNUM, stmtNUM))
  
  apiMedian <- median(newframe$api)
  #newframe$api[newframe$api > 0] <- 1
  newframe$api[newframe$api > apiMedian] <- 1
  newframe$api[newframe$api <= apiMedian] <- 0
  
  stateMedian <- median(newframe$state)
  #newframe$state[newframe$state > 0] <- 1
  newframe$state[newframe$state > stateMedian] <- 1
  newframe$state[newframe$state <= stateMedian] <- 0
  
  funcMedian <- median(newframe$func)
  #newframe$func[newframe$func > 0] <- 1
  newframe$func[newframe$func > funcMedian] <- 1
  newframe$func[newframe$func <= funcMedian] <- 0
  
  stmtMedian <- median(newframe$stmt)
  #newframe$stmt[newframe$stmt > 0] <- 1
  newframe$stmt[newframe$stmt > stmtMedian] <- 1
  newframe$stmt[newframe$stmt <= stmtMedian] <- 0
  
  # condMedian <- median(newframe$cond)
  # #newframe$cond[newframe$cond > 0] <- 1
  # newframe$cond[newframe$cond > condMedian] <- 1
  # newframe$cond[newframe$cond <= condMedian] <- 0
  
  mydata <- cbind(mydata, newframe)
  return (mydata)
}

RemoveConfoundingEffect <- function(data, ynames, confounding.effect.name="LOC")
{
  #### confounding.effect.name: name of the variable in data that each of ynames have confounding effect with
  for (yname in ynames) {
    if (yname==confounding.effect.name) { next } #continue
    
    ## glm(formula, data, family = gaussian) <==> lm(formula, data), but the performation of later one is better 
    # model <- glm(formula=formula, data=data, family=gaussian)
    
    formula <- as.formula(paste(yname, confounding.effect.name, sep=" ~ "))
    model <- lm(formula=formula, data=data)
    
    # <==> data[[yname]] <- data[[yname]] - model$fitted.values 
    # could encounter data$yname < 0
    data[, yname] <- data[, yname] - model$fitted.values
  }

  return (data)
}

### stepwise logistic regression variable selection
Stepwise <- function(data, xnames, yname, confounding.effect.name="LOC", rule="aic", direction="forward", remove.cv.flag=FALSE, trace=FALSE)
{
  ### stepwise variable selection
  SubStepwise <- function(data, yname, xnames, rule="aic", direction="forward", trace=FALSE)
  {
    ## cat("step", rule, direction, "\n")
    
    rule <- tolower(rule)
    direction <- tolower(direction)
    
    null.formula <- as.formula(sprintf("%s ~ 1", yname))
    full.formula <- as.formula(sprintf("%s ~ %s", yname, paste(xnames, collapse=" + ")))
    

    # family = binomial <==> family = binomial(link = logit)
    model <- null.model <- full.model <- NULL
    null.model <- glm(null.formula, family=binomial, data=data)
    full.model <- glm(full.formula, family=binomial, data=data)
    
    if (rule=="aic") { k <- 2 } else { k <- log(nrow(data)) }
    scope <- list(upper=full.model, lower=null.model)
    
    if (direction=="forward") {
      model <- step(null.model, scope=scope, direction="forward",  k=k, trace=trace)
    } else if (direction=="backward") {
      model <- step(full.model, scope=scope, direction="backward", k=k, trace=trace)
    } else if (direction=="forwardboth") {
      model <- step(null.model, scope=scope, direction="both",     k=k, trace=trace)
    } else if (direction=="backwardboth") {
      model <- step(full.model, scope=scope, direction="both",     k=k, trace=trace)
    }
    
    return(model)
  }
  
  if (length(xnames)==0) { stop("Length of independent variable is zero. Please check.\n") }
  
  data.new <- data
  if ( remove.cv.flag==TRUE) {
    if (trace) { cat("Removing confounding effect for independent variables before stepwise variable selection.\n") }
    data.new <- RemoveConfoundingEffect(data.new, ynames=xnames, confounding.effect.name=confounding.effect.name)
  }
  
  model <- SubStepwise(data=data.new, yname=yname, xnames=xnames, rule=rule, direction=direction, trace=trace)
  
  return(model)
}

### optimized by Yibiao Yang on 2014-09-11
### REL: real changes in file, taken 0 or 1
### PRE: relative probability value
### NUM: total changes in file
##################################################
ComputeThreshold <- function(data, lt=FALSE) # lower than is faulty
{
  data <- data[order(-data$PRE), ] 
  thresholds <- unique(sort(data$PRE, decreasing=TRUE))
  
  len <- nrow(data)
  TPs <- cumsum(data$REL)        ### true positive
  FPs <- cumsum((1-data$REL))    ### false positive
  
  FNs <- TPs[len] - TPs          ### false negative + true positive = all positive
  TNs <- (len - TPs[len]) - FPs  ### true negative + false positive = all negative
  
  TPR <- TPs / (TPs + FNs)
  TPR[is.na(TPR)] <- 0
  
  Recall <- TPR
  
  FPR <- FPs / (FPs + TNs)
  FPR[is.na(FPR)] <- 0
  
  Precision <- TPs / (TPs + FPs)
  Precision[is.na(Precision)] <- 0
  
  BPP.old <- 1 - sqrt( ( (1-TPR)^2 + (0-FPR)^2 ) / 2 )    ## balance of TPR and FPR
  BCE.old <- abs(1-TPR-FPR)                               ## balance classification error
  MFM.old <- 2 * Recall * Precision / (Recall+Precision)  ## Maximun F-measure
  MFM.old[is.na(MFM.old)] <- 0
  
  pos.equal <- which(data[1:(len-1), "PRE"] == data[2:len, "PRE"])
  
  BPP <- c() 
  BCE <- c()
  MFM <- c()
  
  if(length(pos.equal) == 0) {
    BPP <- BPP.old
    BCE <- BCE.old
    MFM <- MFM.old
  } else {
    BPP <- BPP.old[-pos.equal]
    BCE <- BCE.old[-pos.equal]
    MFM <- MFM.old[-pos.equal]
  }
  
  if(length(BPP) != length(thresholds)) {
    browser()
  }
  
  bpp.threshold <- max(thresholds[which.max(BPP)])
  bce.threshold <- max(thresholds[which.min(BCE)])
  mfm.threshold <- max(thresholds[which.max(MFM)])
  
  return ( list(BPP=bpp.threshold, BCE=bce.threshold, MFM=mfm.threshold) )
}

#####################################################################
# ER : effort reduction compared to random model (model evaluation criteria for cost-effectiveness)
#####################################################################
ComputeER <- function(threshold, data, lt=FALSE) # lower than is faulty
{
  if(lt){
    data$PREBIN <- 1 * (data$PRE <= threshold)
  } else {
    data$PREBIN <- 1 * (data$PRE >= threshold) 
  }
  
  totalLOC   <- sum(data$LOC)
  totalLOC.M <- sum(data$PREBIN*data$LOC)
  
  totalNUM    <- sum(data$NUM)
  totalNUM.R  <- sum(data$PREBIN*data$NUM)
  
  Effort.M <- totalLOC.M / totalLOC
  Effort.R  <- totalNUM.R / totalNUM
  
  if(Effort.R  > 0){
    ER <- (Effort.R - Effort.M) / Effort.R 
  } else if(Effort.R == Effort.M){
    ER <- 0
  } else {
    ER <- -1
  }
  
  return (ER)
}

#######################################################################################################################
### ER: effort reduction compared to random model (model evaluation criteria for cost-effectiveness)
#######################################################################################################################
ComputeERs <- function(data) { ### data <- newValidData
  ## Here, we set the effort-aware
  data <- data[order(-data$PRE, +data$LOC), ]   ## attention: PRE=Relative probability 
  thresholds <- ComputeThreshold(data=data) ## 
  
  lt <- FALSE
  ER.BPP <- ComputeER(threshold=thresholds$BPP, data=data, lt=lt)
  ER.BCE <- ComputeER(threshold=thresholds$BCE, data=data, lt=lt)
  ER.MFM <- ComputeER(threshold=thresholds$MFM, data=data, lt=lt)
  
  thresholds <- data$PRE
  values  <- lapply(thresholds, FUN=ComputeER, data=data, lt=lt)
  ER.AVG <- mean(unlist(values))
  
  ERs <- c(BPP=ER.BPP, BCE=ER.BCE, MFM=ER.MFM, AVG=ER.AVG)
  
  return (ERs)
}

#######################################################################################################################
### CE: cost-effectiveness based on Alberg diagram (model evaluation criteria for cost-effectiveness)
#######################################################################################################################
ComputeCEs <- function(data, cutoffs)
{
  ### compute area under curve for CE
  ComputeCEAreawithCutoffs <- function(data, cutoffs, effortAwareFlag=TRUE)
  {
    len <- nrow(data) # length of test sampling
    ### cumulative sums of LOC or NUM
    cumXs <- cumsum(data$LOC) # x: LOC%
    cumYs <- cumsum(data$NUM) # y: Bug%
    
    Xs <- cumXs/cumXs[len]
    Ys <- cumYs/cumYs[len]
    
    poses <- vector(length=length(cutoffs))  # boolean vector with length，each element is FALSE (default)
    cutoffs.new <- NULL
    if (effortAwareFlag) {
      for (i in seq(length.out=length(cutoffs))) {
        ### find the lowest index which is larger or equal than cutoff
        ### that's to say cutoff is between pos-1 and pos
        cutoff   <- cutoffs[i]
        poses[i] <- min(which(Xs >= cutoff))  ## 
      }
      cutoffs.new <- cutoffs ### x-axis is the corresponding cutoff (effort)
    } else {
      poses <- len*cutoffs ### which
      cutoffs.new <- Xs[poses] ### x-axis
    }
    
    Yposes <- vector(length=length(cutoffs))
    if (effortAwareFlag) {
      for (i in seq(length.out=length(cutoffs))) {
        cutoff <- cutoffs[i]
        pos <- poses[i]
        
        if (pos==1) {
          Yposes[i] <- cutoff * (Ys[1]/Xs[1])
        } else {
          Yposes[i] <- (cutoff-Xs[pos-1]) * ((Ys[pos]-Ys[pos-1])/(Xs[pos]-Xs[pos-1])) + Ys[pos-1]
        }
      }
    } else {
      Yposes <- Ys[poses]
    }
    
    fix_subareas <- vector(length=len)
    fix_subareas[1] <- 0.5 * Ys[1] * Xs[1]
    fix_subareas[2:len] <- 0.5 * (Ys[1:(len-1)] + Ys[2:len]) * abs(Xs[1:(len-1)] - Xs[2:len])
    
    areas      <- vector(length=length(cutoffs))
    RECALLs    <- vector(length=length(cutoffs))
    for (i in seq(length.out=length(poses))) {
      pos <- poses[i]
      Ypos <- Yposes[i]
      cutoff <- cutoffs.new[i]
      
      subareas <- vector(length=pos)
      if (pos==1) {
        subareas[1] <- 0.5 * cutoff * Ypos
      } else if (pos==2) {
        subareas[1] <- fix_subareas[1]
        subareas[2] <- (Ypos+Ys[1])*(abs(cutoff-Xs[1]))*0.5
      } else {
        subareas[1:(pos-1)] <- fix_subareas[1:(pos-1)]
        subareas[pos]  <- (Ypos+Ys[pos-1])*(abs(cutoff-Xs[pos-1]))*0.5
      }
      
      areas[i] <- sum(subareas)
    }
    
    return (areas)
  }
  
  effortAwareFlag <- TRUE ### set by user
  
  ### here, effortaware is setted
  data.mdl <- data[order(-data$PRE, +data$LOC), ]   # where, PRE(Relative Predicion) = change-proneness probability per LOC
  ## compute areas of Alberg's grapgh at given cutoffs for model m 
  areas.mdl <- ComputeCEAreawithCutoffs(data=data.mdl, cutoffs=cutoffs, effortAwareFlag=effortAwareFlag)  #is a vector 
  
  ### here, effortaware is setted
  ### compute areas of Alberg's grapgh at given cutoffs for optimal model
  data$density <- data$NUM/(data$LOC+1)  #changes density
  data.opt <- data[order(-data$density, +data$LOC), ]
  areas.opt <- ComputeCEAreawithCutoffs(data=data.opt, cutoffs=cutoffs, effortAwareFlag=effortAwareFlag)  #is a vector
  
  ### compute areas of Alberg's grapgh at given cutoffs for random model
  areas.random <- 0.5*cutoffs*cutoffs ## is a vector
  
  CEs <- (areas.mdl- areas.random)/(areas.opt - areas.random)  ## is a vector
  
  CEs <- pmin(1, CEs)
  CEs[is.na(CEs)] <- 0
  
  # if (any(is.na(ARs))) { cat("one element of ARs or CEs is NA") }
  
  if (effortAwareFlag ) { 
    names(CEs) <- paste("CE.E", cutoffs, sep=".")
  } else {
    names(CEs) <- paste("CE.P", cutoffs, sep=".")
  }
  
  return (CEs)
}

GetTrainModel <- function(releasePath, trainData, LOCAsIndependVariable, xnames, yname, effortName, cutoffs, confounding.effect.name="LOC", remove.cv.flag=TRUE, trace=FALSE)
{
  if(LOCAsIndependVariable == FALSE) {
    xnames <- xnames[xnames != "LOC"]
  }
  
  formula <- as.formula(sprintf("%s ~ %s", yname, paste(xnames, collapse="+")))
  logitmodel <- glm(formula=formula, family="binomial", data=trainData)
  releaseName <- basename(releasePath)
  
  #######################################################################################################################
  ## Optimization-1: use stepwise to select sufficient independent variables
  #######################################################################################################################
  stepCIAModelError <- tryCatch ({
    beforeModel <- logitmodel
    ##stepmodel <- step(logitmodel, trace = 0)
    ## data, xnames, yname, confounding.effect.name="LOC", rule="aic", direction="forward", remove.cv.flag=FALSE, trace=FALSE
    stepmodel <- Stepwise(data=trainData, xnames, yname, rule="aic", direction="forward", confounding.effect.name="LOC", remove.cv.flag=remove.cv.flag, trace=FALSE)
  }, error = function(e) {
    cat(paste(e), "\n")
    return (e)
  })

  if (inherits(stepCIAModelError, "error") == TRUE) {
    logitmodel <- beforeModel
    # go back to original correct model
    cat("analyzing", releaseName, "| recory stepmodel |", length(xnames), "predictors |", yname , "~", paste(xnames, collapse=" + "), "\n", sep=" ")
  } else {
    logitmodel <- stepmodel
    coef <- summary(logitmodel)$coef
    newPredictors <- rownames(coef)  # automaticly filter out "NA" predictors
    xnames <- newPredictors[newPredictors != "(Intercept)"]
    cat("analyzing", releaseName, "| stepmodel |", length(xnames), "predictors |", yname , "~", paste(xnames, collapse=" + "), "\n", sep=" ")
  }
  
  #######################################################################################################################
  ### Optimization-2: remove VIFs, i.e., eliminate those colinearity independent variables
  #######################################################################################################################
  possibleVIFModelError <- tryCatch (
    {
      correctVIFModel <- logitmodel
      correctXNames <- tempXNames <- xnames
      
      if (length(correctXNames) > 2) {
        xnamesVIF <- car::vif(logitmodel)
        xnamesVIF[is.na(xnamesVIF)] <- 20  # vif > 10 will be ignored
        nonVIFNames <- names(which(xnamesVIF <= 10))
        
        # remove VIFs if exists
        while (length(nonVIFNames) < length(tempXNames) & length(nonVIFNames) > 2) {
          tempXNames <- nonVIFNames
          formula <- as.formula(sprintf("%s ~ %s", yname, paste(nonVIFNames, collapse = " + ")))
          logitmodel <- glm(formula = as.formula(formula), family=binomial(link="logit"), data = trainData)
          
          correctVIFModel <- logitmodel
          correctXNames <- nonVIFNames
          
          xnamesVIFNew <- car::vif(logitmodel) # xnamesVIFNew: vector including name and value
          xnamesVIFNew[is.na(xnamesVIFNew)] <- 20  # vif > 10 will be ignored
          nonVIFNames <- names(which(xnamesVIFNew <= 10))
        }
        
        numNoneVIFs <- length(nonVIFNames)
        if(trace == TRUE) {
          cat("analyzing", releaseName, "| VIFsmodel |", numNoneVIFs, "predictors |", yname , "~", paste(nonVIFNames, collapse=" + "), "\n", sep=" ")
        }
      }
      
    }, error = function(e) {
      cat(paste(e))
      return (e)
    }
  )
  
  if (inherits(possibleVIFModelError, "error") == TRUE) {
    logitmodel <- correctVIFModel
    xnames <- correctXNames
    if(trace == TRUE) {
      cat("analyzing", releaseName, "| recovery VIFsModel |", length(xnames), "predictors |", yname , "~", paste(xnames, collapse=" + "), "\n", sep=" ")
    }
  } else {
    logitmodel <- correctVIFModel
    xnames <- correctXNames
  }
  
  #######################################################################################################################
  ### Optimization-3: remove those influential observations, i.e., remove those nosiy samples
  ### copy from YiBiao Yang & WanYing Wang, 2017-12-30
  #######################################################################################################################
  correctModel <- logitmodel
  correctSelectedData <- trainData
  
  cookDisOutlierError <- tryCatch ({
    DISTANCE_THRESHOLD  <- 1
    cookdistances <- cooks.distance(correctModel)
    cookdistances[is.na(cookdistances)] <- 5  # assign new value for "NA" data
    cookoutliers <- sum(cookdistances >= DISTANCE_THRESHOLD)  # sum of the number of elementS in which each is larger than 1
    
    while (cookoutliers >= 1) {
      tempData <- correctSelectedData[which(cookdistances < DISTANCE_THRESHOLD), ]  # data after filtering influential observations
     
      formula <- as.formula(sprintf("%s ~ %s", yname, paste(xnames, collapse = " + ")))
      logitmodel <- glm(formula = as.formula(formula), family=binomial(link="logit"), data = tempData)
      
      correctModel <- logitmodel
      
      cookdistances <- cooks.distance(correctModel)
      cookdistances[is.na(cookdistances)] <- 5  ## aim at removing this observation
      cookoutliers <- sum(cookdistances >= DISTANCE_THRESHOLD)
      
      correctSelectedData <- tempData
    }
    
    totalcookoutliers <- nrow(trainData) - nrow(correctModel$data)
    if (totalcookoutliers > 0) {
      if(trace == TRUE) {
        cat("analyzing", releaseName, "|", sprintf("CookModel | Remove %d cases which cook distance larger than 1", totalcookoutliers), "\n", sep = " ")
      }
    }
  }, error = function(e) {
    cat(paste(e))
    return (e)
  })
  
  if (inherits(cookDisOutlierError, "error") == TRUE) {
    logitmodel <- correctModel
    if(trace == TRUE) {
      cat("analyzing", releaseName, "| recovery CookModel |", length(xnames), "predictors |", yname , "~", paste(xnames, collapse=" + "), "\n\n", sep=" ")
    }
  } else {
    logitmodel <- correctModel
    if(trace == TRUE) {
      cat("analyzing", releaseName, "| CookModel |", length(xnames), "predictors |", yname , "~", paste(xnames, collapse=" + "), "\n\n", sep=" ")
    }
  }
  
  return (logitmodel)
}

processOneProject <- function(projectName, versionPaths, modelName, xnames, yname, ynameNUM, effortName, cutoffs, remove.cv.flag=FALSE, trace=FALSE) {
  all.matrix.CEs <- NULL
  all.matrix.ERs <- NULL
  rownames <- NULL
  
  N <- length(versionPaths)
  for (i in seq(1, N-1)) {
    eachVersionPath <- versionPaths[i]
    
    trainData <- extractEachStructualChangeType(versionPaths[i])
    logistModel <- GetTrainModel(eachVersionPath, trainData, LOCAsIndependVariable=FALSE, xnames, yname, effortName, cutoffs, confounding.effect.name="LOC", remove.cv.flag=remove.cv.flag, trace=FALSE)
    
    for(j in seq(i+1, N)) {
      validData <- extractEachStructualChangeType(versionPaths[j])
      
      data.new <- validData
      if ( remove.cv.flag==TRUE) {
        if (trace) { cat("Removing confounding effect in test data set.\n") }
        validData <- RemoveConfoundingEffect(data.new, ynames=xnames, confounding.effect.name="LOC")
      }
      
      # subsets <- attr(logistModel$terms, "term.labels")  ## output selected inpendent variabes
      
      predictedValue <- predict(logistModel, validData, type="response")
      if (any(is.na(predictedValue))) { stop("predictedValue is NA") }
      
      newValidData <- data.frame(REL=validData[, yname], 
                             PRE=predictedValue/(validData[, effortName] + 1), 
                             LOC=validData[, effortName], 
                             NUM=validData[, ynameNUM])
      CEs <- ComputeCEs(data=newValidData, cutoffs=cutoffs)  ##CEs is vector
      ERs <- ComputeERs(data=newValidData) ## c(BPP=BPP, BCE=BCE, AVG=AVG)
      ##ERs is vector  ## CE.P.0.1 CE.P.0.2, CE.P.1  BPP=BPP, BCE=BCE, MFM=MFM, AVG=AVG
      
      sourceVersionNum <- sub("\\.csv", "", basename(versionPaths[i]))
      targetVersionNum <- sub("\\.csv", "", basename(versionPaths[j]))
      versionPairName <- paste(projectName, ".", modelName, ".", sourceVersionNum, "-->", targetVersionNum, sep="")
      rownames <- c(rownames, versionPairName)
      
      ##cat("processing...", versionPairName, "\n")
      
      all.matrix.CEs <- rbind(all.matrix.CEs, CEs)  ## CE.P.0.1 CE.P.0.2, CE.P.1
      all.matrix.ERs <- rbind(all.matrix.ERs, ERs)  ## BPP=BPP, BCE=BCE, MFM=MFM, AVG=AVG
    }
  }
  
  rownames(all.matrix.CEs) <- paste("CE.", rownames, sep="")
  rownames(all.matrix.ERs) <- paste("ER.", rownames, sep="")
  
  list <- list(matrix.CEs=all.matrix.CEs, matrix.ERs=all.matrix.ERs)

  return (list)
}

processMultipleProject <- function(projectNames, modelComparisonNames, ynames, ynamesNUM, cutoffs, remove.cv.flag=FALSE, outputPath) {
  for (projectName in projectNames) {
    readPath <- paste("C:/Desktop/apsec/SortedSimplifiedVersionPath", "/", projectName, ".csv", sep="")
    versionPaths <- read.table(readPath, header=FALSE, blank.lines.skip = TRUE, stringsAsFactors=FALSE, na.strings = c("NA"))
    versionPaths <- versionPaths[, "V1"]
    
    for(i in seq(1:length(ynames))) {
      yname <- ynames[i]
      ynameNUM <- ynamesNUM[i]

      for (mdlComparisonName in modelComparisonNames) {
        ## consider each for each project 
        eachModelResult <- NULL  
        cat("Processing", projectName, "for", mdlComparisonName,  "model, yname=", yname, "\n\n")
        
        ## process basic model
        cat("Processing", projectName, "for",  "B model, yname=", yname, "\n")
        Bxnames <- c("LOC", "WMC", "DIT", "NOC", "CBO", "RFC", "LCOM")
        Bresult <- processOneProject(projectName, versionPaths, modelName="B", xnames=Bxnames, yname=yname, ynameNUM=ynameNUM, effortName="LOC", 
                                     remove.cv.flag=remove.cv.flag, cutoffs=cutoffs)
        
        ## process model S
        if(mdlComparisonName == "B-VS-S") {
          Sxnames <- c("LOC", "ANOS", "SCM", "SRL", "ASC", "NODC")
          cat("Processing", projectName, "for",  "S model, yname=", yname, "\n")
          Sresult <- processOneProject(projectName, versionPaths, modelName="S", xnames=Sxnames, yname=yname, ynameNUM=ynameNUM, effortName="LOC", 
                                       remove.cv.flag=remove.cv.flag, cutoffs=cutoffs)
          eachModelResult <- list(B=Bresult, S=Sresult)
        }
        
        ## process model B+S
        if(mdlComparisonName == "B-VS-BS") {
          BSxnames <- c("LOC", "WMC", "DIT", "NOC", "CBO", "RFC", "LCOM", "ANOS", "SCM", "SRL", "ASC", "NODC")
          cat("Processing", projectName, "for",  "B+S model, yname=", yname, "\n")
          BSresult <- processOneProject(projectName, versionPaths, modelName="BS", xnames=BSxnames, yname=yname, ynameNUM=ynameNUM, effortName="LOC", 
                                        remove.cv.flag=remove.cv.flag, cutoffs=cutoffs)
          eachModelResult <- list(B=Bresult, "B+S"=BSresult)
        }
        
        ## output data to the destination
        fout <- paste(outputPath,"/data_", projectName, "_", yname, "_", mdlComparisonName, sep="")
        
        ## check whether exists such file or directory
        parent.directory <- dirname(fout)
        while (file.exists(parent.directory) == FALSE){
          dir.create(parent.directory, recursive = TRUE)
          parent.directory <- dirname(parent.directory)
        }
        file.create(fout) 
        
        dput(eachModelResult, file=fout)
        
        print(eachModelResult)
      }
    }
  }
}

GetPridictedProbability <- function(projectName, versionPaths, xnames, yname, ynameNUM, effortName, cutoffs, remove.cv.flag=FALSE, trace=FALSE, outputPath) {
  cat("Processing", projectName, ", yname=", yname, "\n\n")
  
  N <- length(versionPaths)
  allResult <- NULL
  for (i in seq(1, N-1)) {
    eachVersionPath <- versionPaths[i]
    
    ## process basic model
    Bxnames <- c("LOC", "WMC", "DIT", "NOC", "CBO", "RFC", "LCOM")
    ## process model S
    Sxnames <- c("LOC", "ANOS", "SCM", "SRL", "ASC", "NODC")
    ## process model B+S
    BSxnames <- c("LOC", "WMC", "DIT", "NOC", "CBO", "RFC", "LCOM", "ANOS", "SCM", "SRL", "ASC", "NODC")
    
    trainData <- extractEachStructualChangeType(versionPaths[i])
    logistModelB <- GetTrainModel(eachVersionPath, trainData, LOCAsIndependVariable=FALSE, xnames=Bxnames, yname, effortName, cutoffs, confounding.effect.name="LOC", 
                                 remove.cv.flag=remove.cv.flag, trace=FALSE)
    logistModelS <- GetTrainModel(eachVersionPath, trainData, LOCAsIndependVariable=FALSE, xnames=Sxnames, yname, effortName, cutoffs, confounding.effect.name="LOC", 
                                  remove.cv.flag=remove.cv.flag, trace=FALSE)
    logistModelBS <- GetTrainModel(eachVersionPath, trainData, LOCAsIndependVariable=FALSE, xnames=BSxnames, yname, effortName, cutoffs, confounding.effect.name="LOC", 
                                  remove.cv.flag=remove.cv.flag, trace=FALSE)
    for(j in seq(i+1, N)) {
      validData <- extractEachStructualChangeType(versionPaths[j])
      
      data.new <- validData
      if ( remove.cv.flag==TRUE) {
        if (trace) { cat("Removing confounding effect in test data set.\n") }
        validData <- RemoveConfoundingEffect(data.new, ynames=xnames, confounding.effect.name="LOC")
      }

      predictedValueB <- predict(logistModelB, validData, type="response")
      predictedValueS <- predict(logistModelS, validData, type="response")
      predictedValueBS <- predict(logistModelBS, validData, type="response")
      
      if (any(is.na(predictedValueB))) { stop("predictedValueB is NA") }
      if (any(is.na(predictedValueS))) { stop("predictedValueS is NA") }
      if (any(is.na(predictedValueBS))) { stop("predictedValueBS is NA") }
      
      newValidData <- data.frame(REL=validData[, yname], 
                                 PRE_B1=predictedValueB, 
                                 PRE_S1=predictedValueS, 
                                 PRE_BS1=predictedValueBS, 
                                 
                                 PRE_B2=predictedValueB/(validData[, effortName] + 1), 
                                 PRE_S2=predictedValueS/(validData[, effortName] + 1), 
                                 PRE_BS2=predictedValueBS/(validData[, effortName] + 1), 
                                 
                                 LOC=validData[, effortName], 
                                 NUM=validData[, ynameNUM])
      validData <- cbind(validData, newValidData)
      
      sourceVersionNum <- sub("\\.csv", "", basename(versionPaths[i]))
      targetVersionNum <- sub("\\.csv", "", basename(versionPaths[j]))
      versionPairName <- paste(projectName, ".", sourceVersionNum, "-->", targetVersionNum, sep="")
      newRowNames <- paste(versionPairName, ".", rownames(validData), sep="")
      rownames(validData) <- newRowNames
      
      cat("processing...", versionPairName <- paste(projectName, ".", sourceVersionNum, " (train) --> ", targetVersionNum, " (valid)", sep=""), "\n")
      
      #print(validData)
      
      allResult <- rbind(allResult, validData)
    }
  }

  # ## output data to the destination
  fout <- paste(outputPath,"/case_study_", projectName, "_", yname, ".csv", sep="")
  
  # ## check whether exists such file or directory
  parent.directory <- dirname(fout)
  while (file.exists(parent.directory) == FALSE){
    dir.create(parent.directory, recursive = TRUE)
    parent.directory <- dirname(parent.directory)
  }
  file.create(fout) 
  
  #dput(allResult, file=fout)
  #write.csv(allResult, fout)
  
  #print(allResult)
  
  return (allResult)
}

# CaseStudy <- function(projectNames, modelComparisonNames, ynames, ynamesNUM, cutoffs, remove.cv.flag=FALSE, outputPath) {
#   for (projectName in projectNames) {
#     readPath <- paste("C:/Desktop/apsec/SortedSimplifiedVersionPath", "/", projectName, ".csv", sep="")
#     versionPaths <- read.table(readPath, header=FALSE, blank.lines.skip = TRUE, stringsAsFactors=FALSE, na.strings = c("NA"))
#     versionPaths <- versionPaths[, "V1"]
#     
#     for(i in seq(1:length(ynames))) {
#       yname <- ynames[i]
#       ynameNUM <- ynamesNUM[i]
#       
#       for (mdlComparisonName in modelComparisonNames) {
#         ## consider each for each project 
#         eachModelResult <- NULL  
#         cat("Processing", projectName, "for", mdlComparisonName,  "model, yname=", yname, "\n\n")
#         
#         GetPridictedProbability(projectName, versionPaths, yname=yname, ynameNUM=ynameNUM, effortName="LOC", 
#                                      remove.cv.flag=remove.cv.flag, cutoffs=cutoffs, outputPath=outputPath)
#       }
#     }
#   }
# }

##################################################################################################################################
## main function
##################################################################################################################################
projectNames <- c("camel", "derby", "elasticsearch", "hive", "lucene", "pig") ## total=6

ynames <- c("api", "func", "state", "stmt")
ynamesNUM <- c("apiNUM", "funcNUM", "stateNUM", "stmtNUM")

modelComparisonNames <- c("B-VS-S", "B-VS-BS")

ioPath <- "C:/Desktop/apsec/result-LOCAsIndependent(true)-RemoveCV(true)"
processMultipleProject(projectNames, modelComparisonNames, ynames, ynamesNUM, cutoffs=c(0.1, 0.2, 1), remove.cv.flag=TRUE, outputPath=paste(ioPath, "/data", sep="") )

#table.effort.ranking2(projectNames, ynames, modelComparisonNames, cutoffs=c(0.1, 0.2, 1), inputPath=ioPath, outputPath=ioPath)
#table.effort.classification2(projectNames, ynames, modelComparisonNames, cutoffs=c("BPP","BCE","AVG"), inputPath=ioPath, outputPath=ioPath)

##plot.single.effort.ranking(projectNames, ynames, modelComparisonNames, cutoffs=c(0.1, 0.2, 1), inputPath=ioPath, outputPath=ioPath)
##plot.single.effort.classification(projectNames, ynames, modelComparisonNames, cutoffs=c("BPP", "BCE", "AVG"), inputPath=ioPath, outputPath=ioPath)

#######################################################
##following code is ignored
#ioPath <- "C:/Desktop/apsec/CaseStudy"
#CaseStudy(projectNames, modelComparisonNames, ynames, ynamesNUM, cutoffs=c(0.1, 0.2, 1), remove.cv.flag=FALSE, outputPath=paste(ioPath, "/data", sep="") )
#######################################################
