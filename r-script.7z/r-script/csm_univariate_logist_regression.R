
#######################################################################################
### recommended RStudio to run the following code
### NOTICE: sometimes you need to set working directory, e.g.:
### setwd("C:/Desktop/lhh/dc")
### install.packages("packagename")
###
### library(lsr, quietly=TRUE) => lsr.d = lsr::cohensD(x, y)
### print(paste("lsr.d = ", lsr.d, sep=""), quote=F)
### 
### library(effsize, quietly=TRUE) => effsize.d = effsize::cohen.d(x, y)
### print(paste("effsize.d = ", effsize.d$estimate, sep="") , quote=F)
###
### modified by lhh in 2018-06-14
#######################################################################################

# library(car)
# library(perturb)
# library(plyr, quietly=TRUE)
# library(usdm, quietly=TRUE)
# library(effsize, quietly=TRUE)

rm(list = ls()) ## run rm before starting to find potential bugs, e.g., unvalid variables

RemoveConfoundingEffect <- function(data, ynames, confeff.name="LOC")
{   
  #### confeff.name: name of the variable in data that each of ynames have confounding effect with
  for (yname in ynames) {
    if (yname==confeff.name) { next } # continue
    
    ## glm(formula, data, family = gaussian) <==> lm(formula, data), but the performation of later one is better 
    formula <- as.formula(paste(yname, confeff.name, sep=" ~ "))
    
    # model <- glm(formula=formula, data=data, family=gaussian)
    model <- lm(formula=formula, data=data)
    
    # <==> data[[yname]] <- data[[yname]] - model$fitted.values 
    # could encounter data$yname < 0
    data[, yname] <- data[, yname] - model$fitted.values 
  } 
  return (data)
}

### univariate logistic regression analysis
### confeff.name: confounding variable = LOC
### remove.flag: whether remove the confounding variable (LOC) in univariate logistic regression model
UnivariateLogisticAnalysis <- function(projectName, data, family=binomial, yname, xnames, confeff.name="LOC", remove.flag=FALSE, trace=FALSE)
{
    data[[yname]][data[[yname]] > 0] <- 1     ## assign(x): dependent variable convertion
    
		ulr.results <- data.frame(matrix(0, nrow = 5, ncol = 5))
		rownames(ulr.results) <- paste(projectName, ".", xnames, sep="")
		colnames(ulr.results) <- c("Constant", "Coefficient", "PV", "OR", "Std.Error")
		
		if (remove.flag) {
			data <- RemoveConfoundingEffect(data, ynames=xnames, confeff.name=confeff.name)
		}
		
		for (i in 1:length(xnames)) {
			xname <- xnames[i]
			if (trace) { cat("Independent name:", xname, "\n") }

			tdata <- data
			fm <- paste(yname, xname, sep="~") ### ("%s ~ %s", yname, xname)
			logistml <- glm(as.formula(fm), data=tdata, family=binomial)
			ul.sum <- summary(logistml)

			if (is.na(logistml$coefficients[xname])) {
				ulr.results[i, "Constant"] <- logistml$coefficients["(Intercept)"]
			} else {
				ulr.results[i, "Constant"]    <- ul.sum$coefficients["(Intercept)", "Estimate"]
				ulr.results[i, "Coefficient"] <- ul.sum$coefficients[xname, "Estimate"]
				ulr.results[i, "Std.Error"] <- ul.sum$coefficients[xname, "Std. Error"]
				ulr.results[i, "PV"] <- ul.sum$coefficients[xname, "Pr(>|z|)"]

				coef <- logistml$coefficients[xname] # coefficient
				asd  <- sd(tdata[, xname])
				delta_OR <- exp(coef *asd)
				ulr.results[i, "OR"] <- delta_OR  # delta_OR
			}
		}
		ulr.results[, "PV.Adj"] <- p.adjust(p=ulr.results[, "PV"], method="BH")
		return (ulr.results)  ## data.frame
}

##########################################################################################################################  
## RQ1: Are the smell-based metrics positively correlated with structural change-proneness?
##########################################################################################################################  
RQ1 <- function(projectNames, remove.flag=FALSE, trace=FALSE)
{
  ### all independent variable names
  xnames <- c("ANOS","SCM","SRL","ASC","NODC")
  allResult <- NULL
	for (projectName in projectNames) {
	  readPath <- paste("C:/Desktop/apsec/SortedSimplifiedVersionPath", "/", projectName, ".csv", sep="")
	  versionPaths <- read.table(readPath, header=FALSE, blank.lines.skip = TRUE, stringsAsFactors=FALSE, na.strings = c("NA"))
	  versionPaths <- versionPaths[, "V1"]
	  ## exract data
	  data <- NULL
	  for (eachVersionPath in versionPaths) {
	    releaseData <- read.csv(eachVersionPath, header = TRUE, sep = ",", stringsAsFactors = FALSE)
	    data <- rbind(data, releaseData) # cummulate all data of a studied project
	  }
	  
	  ##  normalization processing
	  # colname <- "SCC"
	  # colvalue <- data[[colname ]] 
	  # data[[colname]] <- (colvalue-min(colvalue))/(max(colvalue)-min(colvalue))
	  
	  ## result is a data.frame
		result <- UnivariateLogisticAnalysis(projectName, data=data, yname="SCC", xnames=xnames, confeff.name="LOC", remove.flag=remove.flag, trace=FALSE); gc()
		
		print(result)
		
		allResult <- rbind(allResult, result)
	}
	
	fout <- paste( "C:/Desktop/apsec/correlation/univariate_logist_result_remove_flag(", remove.flag, ").csv", sep="")
	#parent.directory <- dirname(fout)
	#if (file.exists(parent.directory) == FALSE) { dir.create(parent.directory); file.create(fout)}
	## check whether exists such file or directory
	parent.directory <- dirname(fout)
	while (file.exists(parent.directory) == FALSE){
	  dir.create(parent.directory, recursive = TRUE)
	  parent.directory <- dirname(parent.directory)
	}
	file.create(fout)
	
	write.csv(allResult, file=fout, row.names = TRUE, fileEncoding = "GBK")
}

######################################################################################################################
###  main function
######################################################################################################################
projectNames <- c("camel", "derby", "elasticsearch", "hive", "lucene", "pig") ## ## total=6
#projectNames <- c("camel") ## ## total=6

#rootDirectory <- "C:/Desktop/apsec/OOM+CSM"
#allFiles = list.files(rootDirectory, all.files = FALSE, full.names = TRUE, include.dirs = FALSE, recursive = FALSE)  # return a vecotor
#projectRootDirectories <- allFiles[file.info(allFiles)$isdir]  # extact all dirs
#projectRootDirectories <- c(projectRootDirectories[1])

RQ1(projectNames, remove.flag=FALSE); gc()
RQ1(projectNames, remove.flag=TRUE)

